import { featureFlags } from '../../utils/featureFlags';

describe('featureFlags', () => {
  it('is defined', () => {
    expect(featureFlags).toBeDefined();
  });

  // Add more specific tests for featureFlags
});
