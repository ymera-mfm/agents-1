const styleMock = {};
module.exports = styleMock;
