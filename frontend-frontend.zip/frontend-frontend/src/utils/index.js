// Auto-generated utility exports
