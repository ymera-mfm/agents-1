// Config utility wrapper
// Re-exports config from config directory for backward compatibility

export { config } from '../config/config';
export default config;
