// Logger utility wrapper
// Re-exports logger from services for backward compatibility

export { logger, log } from '../services/logger';
export default logger;
