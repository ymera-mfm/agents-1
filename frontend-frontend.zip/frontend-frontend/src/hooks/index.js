// Auto-generated hook exports
