// Jest CSS mock
// Used to mock CSS/SCSS imports in tests
module.exports = {};
