
import jwt
import uuid
from datetime import datetime, timedelta
from typing import Dict, Optional
from fastapi import HTTPException, status
from redis import asyncio as aioredis
import logging

logger = logging.getLogger(__name__)

class JWTError(Exception):
    """Custom exception for JWT related errors."""
    pass

class SecureJWTManager:
    """Military-grade JWT management with revocation support.
    
    Supports symmetric (HS256, HS512) and asymmetric (RS256) algorithms.
    For HS algorithms, a strong secret key is required.
    For RS256, private_key for signing and public_key for verification are needed.
    """
    
    def __init__(self, redis_client: aioredis.Redis, secret_or_private_key: str, algorithm: str = "HS512", public_key: Optional[str] = None):
        self.redis = redis_client
        self.secret_or_private_key = secret_or_private_key
        self.public_key = public_key if public_key else secret_or_private_key # For symmetric, public_key is the same as secret
        self.blacklist_prefix = "jwt_blacklist:"
        self.algorithm = algorithm

        if self.algorithm.startswith("HS") and len(self.secret_or_private_key) < 32:
            raise ValueError("For HS algorithms, secret_key must be at least 32 bytes (256 bits) for security.")
        if self.algorithm.startswith("RS") and not public_key:
            raise ValueError("For RS algorithms, a public_key must be provided for verification.")

        logger.info(f"SecureJWTManager initialized with algorithm: {self.algorithm}")
    
    async def create_token(self, payload: Dict, expires_delta: timedelta) -> str:
        """Create JWT token with enhanced security features"""
        # Add unique JTI for revocation tracking
        jti = str(uuid.uuid4())
        to_encode = payload.copy()
        to_encode.update({
            "jti": jti,
            "exp": datetime.utcnow() + expires_delta,
            "iat": datetime.utcnow(),
            "iss": "ymera-supreme-manager",  # Specific issuer
            "aud": "ymera-agents",  # Specific audience
        })
        try:
            return jwt.encode(to_encode, self.secret_or_private_key, algorithm=self.algorithm)
        except Exception as e:
            logger.error(f"Error encoding JWT: {e}", exc_info=True)
            raise JWTError("Failed to create JWT token") from e
    
    async def revoke_token(self, jti: str, exp: datetime) -> None:
        """Revoke token by adding to blacklist"""
        ttl = int((exp - datetime.utcnow()).total_seconds())
        if ttl > 0:  # Only blacklist if token hasn't expired
            await self.redis.setex(f"{self.blacklist_prefix}{jti}", ttl, "revoked")
            logger.info(f"Token {jti} blacklisted for {ttl} seconds.")
        else:
            logger.warning(f"Attempted to blacklist an already expired token {jti}.")
    
    async def is_token_blacklisted(self, jti: str) -> bool:
        """Check if token is blacklisted"""
        return await self.redis.exists(f"{self.blacklist_prefix}{jti}")
    
    async def verify_token(self, token: str) -> Dict:
        """Verify token with comprehensive security checks"""
        try:
            # Decode token using the appropriate key (public for RS, secret for HS)
            payload = jwt.decode(
                token, 
                self.public_key, # Use public_key for verification (can be secret for HS)
                algorithms=[self.algorithm],
                issuer="ymera-supreme-manager",
                audience="ymera-agents"
            )
            
            # Check expiration (jwt.decode handles this, but explicit check adds clarity)
            if datetime.utcnow() > datetime.fromtimestamp(payload["exp"]):
                raise jwt.ExpiredSignatureError("Token has expired")
            
            # Check blacklist
            if "jti" in payload and await self.is_token_blacklisted(payload["jti"]):
                raise JWTError("Token has been revoked")
            
            return payload
            
        except jwt.ExpiredSignatureError:
            logger.warning("JWT verification failed: Token has expired.")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )
        except jwt.InvalidTokenError as e:
            logger.warning(f"JWT verification failed: Invalid token. Details: {e}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication token"
            ) from e
        except JWTError as e:
            logger.warning(f"JWT verification failed: {e}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=str(e)
            ) from e
        except Exception as e:
            logger.error(f"Unexpected error during JWT verification: {e}", exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Internal server error during token verification"
            ) from e

    async def health_check(self) -> str:
        """Perform a health check on the JWT manager."""
        try:
            # Attempt to create and verify a dummy token
            dummy_payload = {"test": True}
            dummy_token = await self.create_token(dummy_payload, timedelta(seconds=10))
            await self.verify_token(dummy_token)
            return "healthy"
        except Exception as e:
            logger.error(f"JWT Manager health check failed: {e}", exc_info=True)
            return "unhealthy"


