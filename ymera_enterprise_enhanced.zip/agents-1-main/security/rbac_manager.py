
import logging
from enum import Enum
from typing import Dict, Any, List, Optional
from fastapi import Depends, HTTPException, status
from jose import jwt, JWTError
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from config import settings
from database.secure_database_manager import SecureDatabaseManager
from models.secure_models import User # Assuming User model is defined in secure_models.py
from security.secure_jwt_manager import SecureJWTManager

logger = logging.getLogger(__name__)

class Permission(str, Enum):
    """Defines granular permissions for the system."""
    # Agent Management
    MANAGE_AGENTS = "manage:agents"
    VIEW_AGENTS = "view:agents"
    
    # Task Management
    CREATE_TASKS = "create:tasks"
    VIEW_TASKS = "view:tasks"
    UPDATE_TASKS = "update:tasks"
    DELETE_TASKS = "delete:tasks"
    
    # AI Services
    USE_AI = "use:ai"
    
    # Analytics
    VIEW_ANALYTICS = "view:analytics"
    
    # User and Role Management
    MANAGE_USERS = "manage:users"
    MANAGE_ROLES = "manage:roles"
    
    # System Configuration
    MANAGE_CONFIG = "manage:config"
    
    # High Availability & Disaster Recovery
    MANAGE_HA = "manage:ha"
    VIEW_HA = "view:ha"
    
    # Security Management
    VIEW_SECURITY = "view:security"
    MANAGE_SECURITY = "manage:security"
    
    # General
    ADMIN = "admin"
    GUEST = "guest"

class Role(str, Enum):
    """Defines system roles with associated permissions."""
    ADMIN = "admin"
    DEVELOPER = "developer"
    OPERATOR = "operator"
    ANALYST = "analyst"
    AGENT = "agent"
    USER = "user"

    @property
    def permissions(self) -> List[Permission]:
        """Returns the list of permissions associated with the role."""
        if self == Role.ADMIN:
            return list(Permission)
        elif self == Role.DEVELOPER:
            return [Permission.VIEW_AGENTS, Permission.CREATE_TASKS, Permission.VIEW_TASKS, Permission.USE_AI, Permission.VIEW_ANALYTICS, Permission.VIEW_SECURITY]
        elif self == Role.OPERATOR:
            return [Permission.MANAGE_AGENTS, Permission.VIEW_AGENTS, Permission.UPDATE_TASKS, Permission.VIEW_TASKS, Permission.MANAGE_HA, Permission.VIEW_HA, Permission.VIEW_SECURITY]
        elif self == Role.ANALYST:
            return [Permission.VIEW_AGENTS, Permission.VIEW_TASKS, Permission.USE_AI, Permission.VIEW_ANALYTICS, Permission.VIEW_SECURITY]
        elif self == Role.AGENT:
            return [Permission.VIEW_TASKS, Permission.UPDATE_TASKS] # Agents can view and update their own tasks
        elif self == Role.USER:
            return [Permission.VIEW_TASKS, Permission.USE_AI]
        return []

class RBACManager:
    """Manages Role-Based Access Control (RBAC) for the application.

    Integrates with the database to fetch user roles and permissions.
    """

    def __init__(self, db_manager: SecureDatabaseManager, jwt_manager: SecureJWTManager):
        self.db_manager = db_manager
        self.jwt_manager = jwt_manager
        logger.info("RBACManager initialized.")

    async def get_user_permissions(self, user_id: str) -> Set[Permission]:
        """Fetches all permissions for a given user from the database."""
        async with self.db_manager.get_session() as session:
            user = await session.get(User, user_id)
            if not user:
                logger.warning(f"User {user_id} not found for permissions check.")
                return set()
            
            user_permissions = set(user.permissions)
            for role_name in user.roles:
                try:
                    role = Role(role_name)
                    user_permissions.update(role.permissions)
                except ValueError:
                    logger.warning(f"Unknown role '{role_name}' for user {user_id}.")
            
            return user_permissions

    async def has_permission(self, user_id: str, required_permission: Permission) -> bool:
        """Checks if a user has a specific permission."""
        user_permissions = await self.get_user_permissions(user_id)
        return required_permission in user_permissions or Permission.ADMIN in user_permissions

    async def get_current_user(self, token: str = Depends(settings.security.jwt.oauth2_scheme)) -> Dict[str, Any]:
        """Dependency to get the current authenticated user from JWT.

        Raises HTTPException if token is invalid or user is not found.
        """
        credentials_exception = HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
        try:
            payload = await self.jwt_manager.verify_token(token)
            user_id: str = payload.get("sub")
            if user_id is None:
                raise credentials_exception
            
            async with self.db_manager.get_session() as session:
                user = await session.get(User, user_id)
                if user is None:
                    raise credentials_exception
                
                # Return a dictionary with user details and their permissions
                return {
                    "id": user.id,
                    "username": user.username,
                    "email": user.email,
                    "roles": user.roles,
                    "permissions": list(await self.get_user_permissions(user.id)),
                    "tenant_id": user.tenant_id
                }
        except JWTError as e:
            logger.warning(f"JWT validation failed: {e}")
            raise credentials_exception from e
        except Exception as e:
            logger.error(f"Error getting current user: {e}", exc_info=True)
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal server error") from e

def require_permission(permission: Permission):
    """Decorator to enforce specific permissions on API endpoints."""
    def permission_checker(current_user: Dict = Depends(get_current_user)):
        if permission not in current_user["permissions"] and Permission.ADMIN not in current_user["permissions"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Not enough permissions. Required: {permission.value}"
            )
        return current_user
    return permission_checker

# Global instance for dependency injection (will be set in lifespan)
_rbac_manager_instance: Optional[RBACManager] = None

def set_rbac_manager_instance(manager: RBACManager):
    global _rbac_manager_instance
    _rbac_manager_instance = manager

async def get_rbac_manager() -> RBACManager:
    if _rbac_manager_instance is None:
        raise RuntimeError("RBACManager not initialized.")
    return _rbac_manager_instance

async def get_current_user_dependency(rbac_manager: RBACManager = Depends(get_rbac_manager),
                                        token: str = Depends(settings.security.jwt.oauth2_scheme)) -> Dict[str, Any]:
    """Dependency function to get the current user, using the initialized RBACManager."""
    return await rbac_manager.get_current_user(token)

# Override the original get_current_user to use the dependency injection pattern
get_current_user = get_current_user_dependency

