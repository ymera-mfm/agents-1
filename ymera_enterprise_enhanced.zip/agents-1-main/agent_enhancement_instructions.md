# Enterprise Production Readiness Instructions for AI Coding Agent (Codestral/Copilot)

**Target Platform:** YMERA Multi-Agent AI System
**Goal:** Achieve Enterprise Production Readiness through technical hardening, performance optimization, and the implementation of critical missing modules.
**Recipient:** AI Coding Agent (e.g., Codestral, GitHub Copilot)
**Mandate:** **Strictly adhere to the attached Code of Conduct.** All implementations must be fully functional, production-ready, and non-theoretical. No placeholders, no `TODO` comments.

## Phase 1: Technical Hardening and Security

The primary goal of this phase is to eliminate known vulnerabilities and enforce enterprise-grade security standards.

### Instruction 1.1: Fix Critical Frontend CSP Vulnerability

**Problem:** The Content Security Policy (CSP) in `frontend/src/services/security.js` currently includes `'unsafe-inline'` and `'unsafe-eval'`, which are critical security risks in a production environment.

**Action:**
1.  **Modify `frontend/src/services/security.js`** to dynamically remove `'unsafe-inline'` and `'unsafe-eval'` from the `script-src` and `style-src` directives when the application is running in a production environment (`process.env.NODE_ENV === 'production'`).
2.  **Implement a build-time check** in `frontend/validate-system.cjs` or a similar script to fail the build if these directives are detected in the production configuration.
3.  **Refactor** any code that relies on these unsafe directives (e.g., in-line event handlers or styles) to use standard React practices (e.g., external stylesheets, event listeners).

### Instruction 1.2: Implement Backend Rate Limiting

**Problem:** The FastAPI application lacks protection against brute-force attacks and resource exhaustion on its REST and WebSocket endpoints.

**Action:**
1.  **Implement a robust rate-limiting mechanism** for all public-facing REST API endpoints (e.g., `/api/v1/commands`, `/api/v1/agents`).
2.  Use a library like `fastapi-limiter` or `starlette-rate-limiter` with Redis (`redis` service in `docker-compose.yml`) as the backend store.
3.  Set a default global limit of **100 requests per minute per IP address**.
4.  **Apply a stricter limit** (e.g., 5 requests per minute) to sensitive endpoints like potential login/authentication routes (if they existed, for future-proofing).

### Instruction 1.3: Enforce HTTPS/HSTS Headers

**Problem:** The current setup does not enforce secure transport headers, which is mandatory for enterprise applications.

**Action:**
1.  **Modify `main.py`** to include the `Strict-Transport-Security` (HSTS) header in all responses.
2.  **Add a middleware** to automatically redirect all HTTP traffic to HTTPS (though this is typically handled by a reverse proxy like Nginx/Traefik in production, the application should be aware).
3.  **Ensure all cookies** (if any are set) are marked with `Secure` and `HttpOnly` flags.

## Phase 2: Missing Core Modules and Scalability

This phase focuses on implementing critical features that enable fault tolerance, true scalability, and business-level functionality.

### Instruction 2.1: Implement Agent State Checkpointing and Persistence

**Problem:** Agents lose their complex, in-progress state upon restart or failure, violating fault-tolerance requirements.

**Action:**
1.  **Modify `base_agent.py`** to include methods for `save_state()` and `load_state()`.
2.  The state should be serialized (e.g., JSON or Pickle) and stored in the **Redis** service (`redis` in `docker-compose.yml`) for fast retrieval.
3.  Implement a **periodic checkpointing mechanism** (e.g., every 60 seconds) within the `BaseAgent`'s main loop.
4.  When an agent is initialized, it **MUST** attempt to `load_state()` from Redis. If a state exists, it resumes; otherwise, it starts fresh.
5.  **Update `database.py`** to store a reference to the latest checkpoint key in Redis on the `Agent` model.

### Instruction 2.2: Implement a Dynamic Agent Configuration Service

**Problem:** The current system lacks a mechanism for users to dynamically configure or tune an agent's behavior (e.g., LLM parameters, tool access) via the UI.

**Action:**
1.  **Backend (`main.py`):**
    *   Create a new REST endpoint: `POST /api/v1/agents/{agent_id}/config` to update an agent's runtime configuration.
    *   Create a new REST endpoint: `GET /api/v1/agents/{agent_id}/schema` that returns a JSON Schema defining the configurable parameters for that specific agent type.
2.  **Frontend (`frontend/src/pages/CommandPage.jsx` and new component):**
    *   Develop a new React component, `DynamicAgentConfigForm.jsx`, that consumes the JSON Schema from the backend and renders a dynamic form (e.g., using `react-hook-form`).
    *   Integrate this form into the `CommandPage` or a new `AgentTuningPage` to allow users to modify and submit new configurations to the backend endpoint.

### Instruction 2.3: Implement Specialized Value-Driving Agent

**Problem:** The platform lacks specialized agents that demonstrate its unique value proposition to a target vertical.

**Action:**
1.  **Create a new agent file: `agent_devops_automation.py`**
2.  Define a new class `DevOpsAgent(BaseAgent)` that specializes in:
    *   Monitoring a mock external service (simulated by a simple API call).
    *   Executing a "remediation" task (simulated by logging a critical action).
3.  This agent must use the **NATS** message broker to publish a `NOTIFICATION` message when it detects an issue and a `RESPONSE` message when the remediation is complete.
4.  **Integrate the new agent** into the application startup sequence in `main.py`.

## Phase 3: Performance and Observability Optimization

This phase focuses on improving the efficiency of the core systems and enhancing the observability features.

### Instruction 3.1: Optimize WebSocket Broadcast Efficiency

**Problem:** The current `ConnectionManager.broadcast` in `main.py` uses a simple `for` loop, which can be inefficient and block the event loop if the number of connected clients grows large or a client connection is slow.

**Action:**
1.  **Modify `ConnectionManager.broadcast` in `main.py`** to use `asyncio.gather` with a timeout for each `connection.send_text()`.
2.  This allows concurrent sending and prevents a single slow client from blocking the entire broadcast for all other clients.
3.  Implement robust error handling within the gathered coroutines to safely remove failed connections.

### Instruction 3.2: Full NATS JetStream Integration

**Problem:** The system is configured with NATS but does not appear to leverage its advanced features like JetStream for guaranteed message delivery and stream processing, which is essential for enterprise reliability.

**Action:**
1.  **Modify `agent_communication.py`** to initialize a **NATS JetStream context** upon startup.
2.  **Define a Stream** named `AGENT_EVENTS` that persists messages for 7 days.
3.  **Update the `CommunicationAgent`** to use JetStream `publish` for all critical inter-agent messages (e.g., task assignments, state changes).
4.  **Update the `BaseAgent`** to use a JetStream `consumer` to ensure it only acknowledges and processes messages when it is ready, guaranteeing no message loss.

### Instruction 3.3: Frontend Performance Metric Reporting

**Problem:** The frontend has performance utilities but lacks a mechanism to report these metrics to the backend for centralized analysis.

**Action:**
1.  **Frontend (`frontend/src/utils/analytics.js`):** Implement a function `reportWebVitalsToBackend(metric)` that uses `axios` to send performance data (e.g., CLS, LCP, FID) to a new backend endpoint.
2.  **Backend (`main.py`):** Create a new REST endpoint `POST /api/v1/metrics/frontend` to accept and log this performance data.
3.  **Logging:** The backend endpoint should log the received metrics to a dedicated file or the database for later analysis, linking them to a session ID.

---
*(End of Enhancement Instructions)*
