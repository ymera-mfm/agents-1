```mermaid
graph TD
    subgraph Frontend [React Frontend]
        A[Browser UI] -->|WebSocket| B(FastAPI Server);
        A -->|REST API| B;
        A -->|3D Visualization| C(Three.js/Fiber);
    end

    subgraph Backend [Python FastAPI]
        B(FastAPI Server) -->|Agent Management| D[BaseAgent];
        B -->|Real-time Data| E[WebSocket Manager];
        E -->|Broadcast| A;
        D -->|Messaging| F(NATS Message Broker);
        D -->|Metrics| G[MonitoringAgent];
        D -->|Communication| H[CommunicationAgent];
        G -->|Metrics| P[Prometheus];
    end

    subgraph Infrastructure
        F -->|Agent Messaging| D;
        F -->|Agent Messaging| H;
        I[PostgreSQL DB] -->|Async ORM (SQLAlchemy)| B;
        J[Redis Cache] -->|Caching/Session| B;
    end

    B -->|Persist State| I;
    B -->|Cache| J;
    D -->|Persist State| I;
    
    style A fill:#f9f,stroke:#333
    style B fill:#ccf,stroke:#333
    style C fill:#cfc,stroke:#333
    style D fill:#fcc,stroke:#333
    style E fill:#ffc,stroke:#333
    style F fill:#cff,stroke:#333
    style G fill:#fcf,stroke:#333
    style H fill:#fcc,stroke:#333
    style I fill:#eee,stroke:#333
    style J fill:#eee,stroke:#333
    style P fill:#eee,stroke:#333
```
