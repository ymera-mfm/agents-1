```mermaid
graph TD
    subgraph Frontend [React Frontend]
        A[Browser UI] -->|WebSocket| B(FastAPI Server);
        A -->|REST API| B;
        A -->|3D Visualization| C(Three.js/Fiber);
    end

    subgraph Backend [Python FastAPI]
        B -->|Agent Management| D[BaseAgent];
        B -->|Real-time Data| E[WebSocket Manager];
        E -->|Broadcast| A;
        D -->|Messaging| F(NATS Message Broker);
        D -->|Metrics| G[MonitoringAgent];
        D -->|Communication| H[CommunicationAgent];
        G -->|Metrics| P[Prometheus];
    end

    subgraph Infrastructure
        F -->|Agent Messaging| D;
        F -->|Agent Messaging| H;
        I[PostgreSQL DB] -->|Data Persistence| B;
        J[Redis Cache] -->|Caching/Queue| B;
    end

    B --> I;
    B --> J;
    D --> I;
```
