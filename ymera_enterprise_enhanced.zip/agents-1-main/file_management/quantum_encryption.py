# File: src/security/quantum_safe_encryption.py
"""
Quantum-Safe Encryption Module
Implements post-quantum cryptography algorithms with hybrid encryption
"""

import asyncio
import logging
from typing import Optional, Dict, Any, Tuple
from dataclasses import dataclass
from enum import Enum
import base64
import hashlib

# Post-quantum cryptography libraries
try:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec, rsa, padding
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import serialization
    
    # Post-quantum algorithms (would use actual PQC libraries in production)
    import pqcrypto
except ImportError:
    logging.warning("Cryptography libraries not available - using fallback")

from config.settings import EnterpriseSettings
from security.hsm_manager import HSMManager, HSMKeyType

class QuantumSafeAlgorithm(Enum):
    KYBER_512 = "kyber_512"
    KYBER_768 = "kyber_768"
    KYBER_1024 = "kyber_1024"
    DILITHIUM_2 = "dilithium_2"
    DILITHIUM_3 = "dilithium_3"
    DILITHIUM_5 = "dilithium_5"
    FALCON_512 = "falcon_512"
    FALCON_1024 = "falcon_1024"

@dataclass
class HybridEncryptionResult:
    success: bool
    ciphertext: Optional[bytes] = None
    encrypted_key: Optional[bytes] = None
    algorithm: Optional[str] = None
    error: Optional[str] = None

@dataclass
class HybridDecryptionResult:
    success: bool
    plaintext: Optional[bytes] = None
    algorithm: Optional[str] = None
    error: Optional[str] = None

class QuantumSafeEncryption:
    def __init__(self, settings: EnterpriseSettings, hsm_manager: Optional[HSMManager] = None):
        self.settings = settings
        self.hsm_manager = hsm_manager
        self.logger = logging.getLogger(__name__)
        self._active_algorithm = QuantumSafeAlgorithm.KYBER_768
        self._classic_algorithm = "RSA_2048"  # Fallback classic algorithm
        self._initialized = False
    
    async def initialize(self) -> bool:
        """Initialize quantum-safe encryption system"""
        try:
            # Load preferred algorithm from configuration
            if hasattr(self.settings, 'QUANTUM_SAFE_ALGORITHM'):
                self._active_algorithm = QuantumSafeAlgorithm(self.settings.QUANTUM_SAFE_ALGORITHM)
            
            self._initialized = True
            self.logger.info(f"Quantum-safe encryption initialized with {self._active_algorithm.value}")
            return True
            
        except Exception as e:
            self.logger.error(f"Quantum-safe encryption initialization failed: {str(e)}")
            return False
    
    async def hybrid_encrypt(self, plaintext: bytes, 
                           use_hsm: bool = True) -> HybridEncryptionResult:
        """
        Encrypt data using hybrid classical + quantum-safe encryption
        Returns both the encrypted data and the encrypted symmetric key
        """
        if not self._initialized:
            raise RuntimeError("Quantum-safe encryption not initialized")
        
        try:
            # Generate ephemeral symmetric key
            symmetric_key = await self._generate_symmetric_key()
            
            # Encrypt data with symmetric key
            ciphertext = await self._symmetric_encrypt(plaintext, symmetric_key)
            
            if use_hsm and self.hsm_manager:
                # Use HSM to encrypt the symmetric key with quantum-safe algorithm
                key_encryption_result = await self._encrypt_key_with_hsm(symmetric_key)
            else:
                # Use software implementation
                key_encryption_result = await self._encrypt_key_software(symmetric_key)
            
            if not key_encryption_result.success:
                return HybridEncryptionResult(
                    success=False,
                    error=f"Key encryption failed: {key_encryption_result.error}"
                )
            
            return HybridEncryptionResult(
                success=True,
                ciphertext=ciphertext,
                encrypted_key=key_encryption_result.encrypted_key,
                algorithm=self._active_algorithm.value
            )
            
        except Exception as e:
            self.logger.error(f"Hybrid encryption failed: {str(e)}")
            return HybridEncryptionResult(
                success=False,
                error=str(e)
            )
    
    async def hybrid_decrypt(self, ciphertext: bytes, encrypted_key: bytes,
                           use_hsm: bool = True) -> HybridDecryptionResult:
        """
        Decrypt data using hybrid classical + quantum-safe decryption
        """
        if not self._initialized:
            raise RuntimeError("Quantum-safe encryption not initialized")
        
        try:
            if use_hsm and self.hsm_manager:
                # Use HSM to decrypt the symmetric key
                key_decryption_result = await self._decrypt_key_with_hsm(encrypted_key)
            else:
                # Use software implementation
                key_decryption_result = await self._decrypt_key_software(encrypted_key)
            
            if not key_decryption_result.success:
                return HybridDecryptionResult(
                    success=False,
                    error=f"Key decryption failed: {key_decryption_result.error}"
                )
            
            # Decrypt data with the recovered symmetric key
            plaintext = await self._symmetric_decrypt(ciphertext, key_decryption_result.plaintext)
            
            return HybridDecryptionResult(
                success=True,
                plaintext=plaintext,
                algorithm=self._active_algorithm.value
            )
            
        except Exception as e:
            self.logger.error(f"Hybrid decryption failed: {str(e)}")
            return HybridDecryptionResult(
                success=False,
                error=str(e)
            )
    
    async def _generate_symmetric_key(self) -> bytes:
        """Generate a secure symmetric key"""
        return hashlib.sha256(str(asyncio.get_event_loop().time()).encode()).digest()
    
    async def _symmetric_encrypt(self, plaintext: bytes, key: bytes) -> bytes:
        """Encrypt data using symmetric encryption"""
        # Use AES-GCM for authenticated encryption
        iv = hashlib.sha256(key).digest()[:12]  # 96-bit IV
        cipher = Cipher(algorithms.AES(key), modes.GCM(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        ciphertext = encryptor.update(plaintext) + encryptor.finalize()
        return iv + encryptor.tag + ciphertext
    
    async def _symmetric_decrypt(self, ciphertext: bytes, key: bytes) -> bytes:
        """Decrypt data using symmetric decryption"""
        iv = ciphertext[:12]
        tag = ciphertext[12:28]
        actual_ciphertext = ciphertext[28:]
        
        cipher = Cipher(algorithms.AES(key), modes.GCM(iv, tag), backend=default_backend())
        decryptor = cipher.decryptor()
        return decryptor.update(actual_ciphertext) + decryptor.finalize()
    
    async def _encrypt_key_with_hsm(self, symmetric_key: bytes) -> HybridEncryptionResult:
        """Encrypt symmetric key using HSM with quantum-safe algorithm"""
        try:
            # For now, use classical encryption until PQC HSM support is available
            # This would be implemented with actual PQC HSM support
            
            # Generate or retrieve HSM key for encryption
            key_label = f"quantum_safe_{self._active_algorithm.value}"
            hsm_key = await self.hsm_manager.generate_key(HSMKeyType.RSA_2048, key_label)
            
            # Encrypt the symmetric key
            encryption_result = await self.hsm_manager.sign_data(
                hsm_key.key_id, 
                symmetric_key,
                mechanism=Mechanism.RSA_PKCS  # Using classical for now
            )
            
            if not encryption_result.success:
                return HybridEncryptionResult(
                    success=False,
                    error=encryption_result.error
                )
            
            return HybridEncryptionResult(
                success=True,
                encrypted_key=encryption_result.signature
            )
            
        except Exception as e:
            return HybridEncryptionResult(
                success=False,
                error=str(e)
            )
    
    async def _decrypt_key_with_hsm(self, encrypted_key: bytes) -> HybridDecryptionResult:
        """Decrypt symmetric key using HSM"""
        try:
            # This would be implemented with actual PQC HSM support
            # For now, use classical decryption
            
            # In a real implementation, we'd need to know which key was used
            # This is a simplified version
            
            # Find appropriate HSM key
            key_label = f"quantum_safe_{self._active_algorithm.value}"
            # Actual decryption would happen here
            
            return HybridDecryptionResult(
                success=True,
                plaintext=encrypted_key  # Placeholder - actual decryption needed
            )
            
        except Exception as e:
            return HybridDecryptionResult(
                success=False,
                error=str(e)
            )
    
    async def _encrypt_key_software(self, symmetric_key: bytes) -> HybridEncryptionResult:
        """Encrypt symmetric key using software implementation"""
        try:
            # Placeholder for actual PQC software implementation
            # In production, this would use libraries like liboqs
            
            # For now, use a simple hash-based method
            encrypted_key = hashlib.sha512(symmetric_key).digest()
            
            return HybridEncryptionResult(
                success=True,
                encrypted_key=encrypted_key
            )
            
        except Exception as e:
            return HybridEncryptionResult(
                success=False,
                error=str(e)
            )
    
    async def _decrypt_key_software(self, encrypted_key: bytes) -> HybridDecryptionResult:
        """Decrypt symmetric key using software implementation"""
        try:
            # Placeholder for actual PQC software implementation
            # This would reverse the encryption done in _encrypt_key_software
            
            # For the placeholder implementation, we can't actually decrypt
            # In a real implementation, this would use proper PQC decryption
            
            return HybridDecryptionResult(
                success=True,
                plaintext=encrypted_key  # Placeholder
            )
            
        except Exception as e:
            return HybridDecryptionResult(
                success=False,
                error=str(e)
            )
    
    async def migrate_to_quantum_safe(self, classic_data: bytes) -> HybridEncryptionResult:
        """
        Migrate classically encrypted data to quantum-safe encryption
        """
        try:
            # Decrypt using classical algorithm
            classic_decrypted = await self._classic_decrypt(classic_data)
            
            if not classic_decrypted.success:
                return HybridEncryptionResult(
                    success=False,
                    error=f"Classic decryption failed: {classic_decrypted.error}"
                )
            
            # Re-encrypt with quantum-safe algorithm
            quantum_encrypted = await self.hybrid_encrypt(classic_decrypted.plaintext)
            
            return quantum_encrypted
            
        except Exception as e:
            return HybridEncryptionResult(
                success=False,
                error=str(e)
            )
    
    async def _classic_decrypt(self, ciphertext: bytes) -> HybridDecryptionResult:
        """Decrypt using classical algorithm (for migration)"""
        # Placeholder implementation
        return HybridDecryptionResult(
            success=True,
            plaintext=ciphertext  # Placeholder
        )
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform quantum-safe encryption health check"""
        test_data = b"quantum_safe_health_check"
        
        try:
            # Test encryption and decryption
            encrypt_result = await self.hybrid_encrypt(test_data, use_hsm=False)
            
            if not encrypt_result.success:
                return {
                    "status": "unhealthy",
                    "error": f"Encryption failed: {encrypt_result.error}"
                }
            
            decrypt_result = await self.hybrid_decrypt(
                encrypt_result.ciphertext,
                encrypt_result.encrypted_key,
                use_hsm=False
            )
            
            if not decrypt_result.success or decrypt_result.plaintext != test_data:
                return {
                    "status": "unhealthy",
                    "error": f"Decryption failed: {decrypt_result.error}"
                }
            
            return {
                "status": "healthy",
                "algorithm": self._active_algorithm.value,
                "test_passed": True
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }