# File: src/data/lifecycle_manager.py
"""
Intelligent Data Lifecycle Management System
ML-driven data classification, automated tiering, and intelligent archival
"""

import asyncio
import logging
import json
from typing import Dict, List, Optional, Any, Set, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum
import hashlib
import zlib
import bz2
import lzma

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

from config.settings import EnterpriseSettings
from monitoring.metrics import MetricsCollector
from monitoring.audit_logger import EnterpriseAuditLogger
from database.connection_pool import DatabaseConnectionPool
from storage.storage_backend import StorageBackend

class DataClass(Enum):
    HOT = "hot"           # Frequently accessed, performance-critical
    WARM = "warm"         # Occasionally accessed, balanced performance
    COLD = "cold"         # Rarely accessed, cost-optimized
    ARCHIVED = "archived" # Long-term retention, lowest cost
    COMPLIANCE = "compliance" # Regulatory retention requirements

class RetentionPolicy(Enum):
    BUSINESS_CRITICAL = "business_critical"  # 7 years
    OPERATIONAL = "operational"              # 3 years
    TRANSACTIONAL = "transactional"          # 1 year
    TEMPORARY = "temporary"                  # 90 days
    COMPLIANCE = "compliance"                # Based on regulations

@dataclass
class DataLifecyclePolicy:
    policy_id: str
    name: str
    description: str
    data_class: DataClass
    retention_policy: RetentionPolicy
    access_pattern_rules: Dict[str, Any]
    content_based_rules: Dict[str, Any]
    cost_optimization_rules: Dict[str, Any]
    compliance_requirements: List[str]
    enabled: bool
    created_at: datetime
    updated_at: datetime

@dataclass
class DataLifecycleDecision:
    file_id: str
    current_tier: DataClass
    recommended_tier: DataClass
    confidence: float
    reasoning: List[str]
    estimated_cost_savings: float
    estimated_performance_impact: float
    action_required: bool
    scheduled_time: Optional[datetime]

@dataclass
class AccessPattern:
    file_id: str
    access_count: int
    last_access_time: datetime
    access_frequency: float  # accesses per day
    access_pattern: List[datetime]  # timestamps of recent accesses
    seasonal_pattern: Optional[Dict[str, Any]]  # weekly/monthly patterns

class IntelligentLifecycleManager:
    def __init__(self, settings: EnterpriseSettings, 
                 metrics: MetricsCollector,
                 audit_logger: EnterpriseAuditLogger,
                 db_pool: DatabaseConnectionPool,
                 storage_backend: StorageBackend):
        self.settings = settings
        self.metrics = metrics
        self.audit_logger = audit_logger
        self.db_pool = db_pool
        self.storage_backend = storage_backend
        self.logger = logging.getLogger(__name__)
        
        self.access_patterns: Dict[str, AccessPattern] = {}
        self.lifecycle_policies: Dict[str, DataLifecyclePolicy] = {}
        self.ml_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
        self.clustering_engine = KMeans(n_clusters=4, random_state=42)
        self.scaler = StandardScaler()
        self._initialized = False
        self._ml_trained = False
    
    async def initialize(self) -> bool:
        """Initialize intelligent lifecycle manager"""
        try:
            # Load lifecycle policies
            await self._load_lifecycle_policies()
            
            # Load historical access patterns
            await self._load_access_patterns()
            
            # Train ML models
            await self._train_ml_models()
            
            # Start background optimization
            asyncio.create_task(self._continuous_optimization())
            
            self._initialized = True
            self.logger.info("Intelligent lifecycle manager initialized")
            return True
            
        except Exception as e:
            self.logger.error(f"Lifecycle manager initialization failed: {str(e)}")
            return False
    
    async def _load_lifecycle_policies(self) -> None:
        """Load data lifecycle policies from database"""
        try:
            async with self.db_pool.get_session() as session:
                # Query policies from database
                result = await session.execute(
                    "SELECT policy_id, name, description, data_class, retention_policy, "
                    "access_pattern_rules, content_based_rules, cost_optimization_rules, "
                    "compliance_requirements, enabled, created_at, updated_at "
                    "FROM data_lifecycle_policies WHERE enabled = true"
                )
                
                policies = result.fetchall()
                
                for policy in policies:
                    lifecycle_policy = DataLifecyclePolicy(
                        policy_id=policy[0],
                        name=policy[1],
                        description=policy[2],
                        data_class=DataClass(policy[3]),
                        retention_policy=RetentionPolicy(policy[4]),
                        access_pattern_rules=json.loads(policy[5]),
                        content_based_rules=json.loads(policy[6]),
                        cost_optimization_rules=json.loads(policy[7]),
                        compliance_requirements=json.loads(policy[8]),
                        enabled=policy[9],
                        created_at=policy[10],
                        updated_at=policy[11]
                    )
                    
                    self.lifecycle_policies[policy[0]] = lifecycle_policy
                
                self.logger.info(f"Loaded {len(policies)} lifecycle policies")
                
        except Exception as e:
            self.logger.error(f"Failed to load lifecycle policies: {str(e)}")
            # Load default policies
            await self._load_default_policies()
    
    async def _load_default_policies(self) -> None:
        """Load default lifecycle policies"""
        default_policies = [
            DataLifecyclePolicy(
                policy_id="default_hot",
                name="Default Hot Data Policy",
                description="Policy for frequently accessed business-critical data",
                data_class=DataClass.HOT,
                retention_policy=RetentionPolicy.BUSINESS_CRITICAL,
                access_pattern_rules={"min_access_frequency": 10, "max_age_days": 30},
                content_based_rules={"content_types": ["application/database", "application/transaction"]},
                cost_optimization_rules={"max_cost_per_gb": 0.10},
                compliance_requirements=[],
                enabled=True,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            ),
            DataLifecyclePolicy(
                policy_id="default_archived",
                name="Default Archived Data Policy",
                description="Policy for long-term retention of rarely accessed data",
                data_class=DataClass.ARCHIVED,
                retention_policy=RetentionPolicy.COMPLIANCE,
                access_pattern_rules={"max_access_frequency": 0.1, "min_age_days": 365},
                content_based_rules={"content_types": ["application/archive", "application/backup"]},
                cost_optimization_rules={"max_cost_per_gb": 0.01},
                compliance_requirements=["GDPR", "HIPAA", "SOC2"],
                enabled=True,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
        ]
        
        for policy in default_policies:
            self.lifecycle_policies[policy.policy_id] = policy
        
        self.logger.info("Loaded default lifecycle policies")
    
    async def _load_access_patterns(self) -> None:
        """Load historical access patterns from database"""
        try:
            async with self.db_pool.get_session() as session:
                # Query access patterns from database
                result = await session.execute(
                    "SELECT file_id, access_count, last_access_time, access_frequency, "
                    "access_pattern, seasonal_pattern FROM file_access_patterns "
                    "WHERE last_access_time > NOW() - INTERVAL '90 days'"
                )
                
                patterns = result.fetchall()
                
                for pattern in patterns:
                    access_pattern = AccessPattern(
                        file_id=pattern[0],
                        access_count=pattern[1],
                        last_access_time=pattern[2],
                        access_frequency=pattern[3],
                        access_pattern=json.loads(pattern[4]) if pattern[4] else [],
                        seasonal_pattern=json.loads(pattern[5]) if pattern[5] else None
                    )
                    
                    self.access_patterns[pattern[0]] = access_pattern
                
                self.logger.info(f"Loaded {len(patterns)} access patterns")
                
        except Exception as e:
            self.logger.error(f"Failed to load access patterns: {str(e)}")
    
    async def _train_ml_models(self) -> None:
        """Train ML models for intelligent data classification"""
        try:
            # Prepare training data
            X, y = await self._prepare_training_data()
            
            if len(X) > 100:  # Need sufficient data for training
                # Scale features
                X_scaled = self.scaler.fit_transform(X)
                
                # Train classifier
                self.ml_classifier.fit(X_scaled, y)
                
                # Train clustering for pattern discovery
                self.clustering_engine.fit(X_scaled)
                
                self._ml_trained = True
                self.logger.info("ML models trained successfully")
            else:
                self.logger.warning("Insufficient data for ML training")
                
        except Exception as e:
            self.logger.error(f"ML model training failed: {str(e)}")
    
    async def _prepare_training_data(self) -> Tuple[List[List[float]], List[str]]:
        """Prepare training data for ML models"""
        X = []  # Features
        y = []  # Labels (data classes)
        
        for file_id, pattern in self.access_patterns.items():
            # Extract features from access pattern
            features = [
                pattern.access_frequency,
                pattern.access_count,
                (datetime.utcnow() - pattern.last_access_time).total_seconds() / 86400,  # days since last access
                len(pattern.access_pattern),
                self._calculate_seasonality_score(pattern.seasonal_pattern)
            ]
            
            # Determine current class (this would come from database in production)
            current_class = self._infer_current_class(pattern)
            
            X.append(features)
            y.append(current_class)
        
        return X, y
    
    def _calculate_seasonality_score(self, seasonal_pattern: Optional[Dict[str, Any]]) -> float:
        """Calculate seasonality score from pattern data"""
        if not seasonal_pattern:
            return 0.0
        
        # Simple implementation - would use proper time series analysis in production
        weekly_variance = seasonal_pattern.get('weekly_variance', 0)
        monthly_variance = seasonal_pattern.get('monthly_variance', 0)
        
        return (weekly_variance + monthly_variance) / 2
    
    def _infer_current_class(self, pattern: AccessPattern) -> str:
        """Infer current data class from access pattern"""
        if pattern.access_frequency > 10:
            return DataClass.HOT.value
        elif pattern.access_frequency > 1:
            return DataClass.WARM.value
        elif pattern.access_frequency > 0.1:
            return DataClass.COLD.value
        else:
            return DataClass.ARCHIVED.value
    
    async def analyze_file(self, file_id: str, metadata: Dict[str, Any]) -> DataLifecycleDecision:
        """Analyze file for lifecycle management decisions"""
        if not self._initialized:
            raise RuntimeError("Lifecycle manager not initialized")
        
        try:
            # Get current access pattern
            access_pattern = self.access_patterns.get(file_id)
            if not access_pattern:
                access_pattern = await self._create_access_pattern(file_id)
            
            # Extract features for ML prediction
            features = await self._extract_features(file_id, access_pattern, metadata)
            
            # Predict optimal data class
            recommended_class, confidence = await self._predict_optimal_class(features)
            
            # Apply policy rules
            final_recommendation, reasoning = await self._apply_policy_rules(
                file_id, recommended_class, confidence, metadata
            )
            
            # Calculate cost and performance impact
            cost_savings = await self._calculate_cost_savings(
                metadata.get('current_tier', DataClass.HOT.value),
                final_recommendation.value,
                metadata.get('file_size', 0)
            )
            
            performance_impact = await self._calculate_performance_impact(
                metadata.get('current_tier', DataClass.HOT.value),
                final_recommendation.value
            )
            
            decision = DataLifecycleDecision(
                file_id=file_id,
                current_tier=DataClass(metadata.get('current_tier', DataClass.HOT.value)),
                recommended_tier=final_recommendation,
                confidence=confidence,
                reasoning=reasoning,
                estimated_cost_savings=cost_savings,
                estimated_performance_impact=performance_impact,
                action_required=cost_savings > 10 or performance_impact < -0.1,  # Thresholds
                scheduled_time=datetime.utcnow() + timedelta(hours=1)  # Schedule for off-peak
            )
            
            # Log decision
            await self.audit_logger.log_lifecycle_decision(decision)
            
            return decision
            
        except Exception as e:
            self.logger.error(f"File analysis failed for {file_id}: {str(e)}")
            raise
    
    async def _create_access_pattern(self, file_id: str) -> AccessPattern:
        """Create new access pattern for file"""
        pattern = AccessPattern(
            file_id=file_id,
            access_count=0,
            last_access_time=datetime.utcnow(),
            access_frequency=0.0,
            access_pattern=[],
            seasonal_pattern=None
        )
        
        self.access_patterns[file_id] = pattern
        return pattern
    
    async def _extract_features(self, file_id: str, pattern: AccessPattern, 
                              metadata: Dict[str, Any]) -> List[float]:
        """Extract features for ML prediction"""
        features = [
            pattern.access_frequency,
            pattern.access_count,
            (datetime.utcnow() - pattern.last_access_time).total_seconds() / 86400,
            len(pattern.access_pattern),
            self._calculate_seasonality_score(pattern.seasonal_pattern),
            metadata.get('file_size', 0) / (1024 * 1024),  # Size in MB
            self._content_type_score(metadata.get('content_type', '')),
            metadata.get('importance_score', 0.5)  # Business importance
        ]
        
        return features
    
    def _content_type_score(self, content_type: str) -> float:
        """Calculate content type score for lifecycle decisions"""
        content_scores = {
            'application/database': 0.9,
            'application/transaction': 0.8,
            'application/document': 0.6,
            'application/archive': 0.3,
            'application/backup': 0.2,
            'application/log': 0.1
        }
        
        return content_scores.get(content_type, 0.5)
    
    async def _predict_optimal_class(self, features: List[float]) -> Tuple[DataClass, float]:
        """Predict optimal data class using ML"""
        if self._ml_trained:
            features_scaled = self.scaler.transform([features])
            prediction = self.ml_classifier.predict(features_scaled)[0]
            confidence = max(self.ml_classifier.predict_proba(features_scaled)[0])
            
            return DataClass(prediction), confidence
        else:
            # Fallback to rules-based approach
            access_frequency = features[0]
            
            if access_frequency > 5:
                return DataClass.HOT, 0.8
            elif access_frequency > 1:
                return DataClass.WARM, 0.7
            elif access_frequency > 0.1:
                return DataClass.COLD, 0.6
            else:
                return DataClass.ARCHIVED, 0.9
    
    async def _apply_policy_rules(self, file_id: str, recommended_class: DataClass,
                                confidence: float, metadata: Dict[str, Any]) -> Tuple[DataClass, List[str]]:
        """Apply policy rules to ML recommendation"""
        reasoning = []
        final_class = recommended_class
        
        # Check compliance requirements
        compliance_requirements = metadata.get('compliance_requirements', [])
        if compliance_requirements:
            # Ensure compliance data stays accessible
            if final_class in [DataClass.COLD, DataClass.ARCHIVED]:
                final_class = DataClass.WARM
                reasoning.append("Elevated to WARM tier for compliance requirements")
        
        # Check business criticality
        business_critical = metadata.get('business_critical', False)
        if business_critical and final_class != DataClass.HOT:
            final_class = DataClass.HOT
            reasoning.append("Elevated to HOT tier for business criticality")
        
        # Check cost constraints
        current_cost = metadata.get('storage_cost', 0)
        recommended_cost = await self._estimate_storage_cost(final_class, metadata.get('file_size', 0))
        
        if recommended_cost > current_cost * 1.5:  # 50% cost increase threshold
            # Find cheaper alternative that meets requirements
            alternative = await self._find_cost_effective_alternative(final_class, metadata)
            if alternative != final_class:
                final_class = alternative
                reasoning.append(f"Changed to {alternative.value} tier for cost optimization")
        
        return final_class, reasoning
    
    async def _estimate_storage_cost(self, data_class: DataClass, file_size: float) -> float:
        """Estimate storage cost for data class"""
        cost_per_gb = {
            DataClass.HOT: 0.10,
            DataClass.WARM: 0.05,
            DataClass.COLD: 0.02,
            DataClass.ARCHIVED: 0.01,
            DataClass.COMPLIANCE: 0.03
        }
        
        return cost_per_gb.get(data_class, 0.10) * (file_size / (1024 * 1024 * 1024))
    
    async def _find_cost_effective_alternative(self, original_class: DataClass, 
                                             metadata: Dict[str, Any]) -> DataClass:
        """Find cost-effective alternative storage class"""
        classes_by_cost = [DataClass.ARCHIVED, DataClass.COLD, DataClass.WARM, DataClass.HOT]
        current_idx = classes_by_cost.index(original_class)
        
        # Try cheaper classes first
        for i in range(current_idx - 1, -1, -1):
            cheaper_class = classes_by_cost[i]
            # Check if cheaper class meets requirements
            if await self._class_meets_requirements(cheaper_class, metadata):
                return cheaper_class
        
        return original_class
    
    async def _class_meets_requirements(self, data_class: DataClass, metadata: Dict[str, Any]) -> bool:
        """Check if data class meets all requirements"""
        # Check access frequency requirements
        access_frequency = metadata.get('access_frequency', 0)
        if data_class == DataClass.HOT and access_frequency < 5:
            return False
        elif data_class == DataClass.WARM and access_frequency < 1:
            return False
        elif data_class == DataClass.COLD and access_frequency < 0.1:
            return False
        
        # Check compliance requirements
        compliance_requirements = metadata.get('compliance_requirements', [])
        if compliance_requirements and data_class == DataClass.ARCHIVED:
            return False
        
        return True
    
    async def _calculate_cost_savings(self, current_tier: str, recommended_tier: str, 
                                    file_size: float) -> float:
        """Calculate estimated cost savings"""
        current_cost = await self._estimate_storage_cost(DataClass(current_tier), file_size)
        recommended_cost = await self._estimate_storage_cost(DataClass(recommended_tier), file_size)
        
        return current_cost - recommended_cost
    
    async def _calculate_performance_impact(self, current_tier: str, recommended_tier: str) -> float:
        """Calculate estimated performance impact"""
        performance_scores = {
            DataClass.HOT: 1.0,
            DataClass.WARM: 0.8,
            DataClass.COLD: 0.5,
            DataClass.ARCHIVED: 0.2,
            DataClass.COMPLIANCE: 0.7
        }
        
        current_score = performance_scores.get(DataClass(current_tier), 1.0)
        recommended_score = performance_scores.get(DataClass(recommended_tier), 1.0)
        
        return recommended_score - current_score
    
    async def execute_lifecycle_action(self, decision: DataLifecycleDecision) -> bool:
        """Execute lifecycle action based on decision"""
        try:
            # Move file to recommended tier
            success = await self.storage_backend.move_to_tier(
                decision.file_id, 
                decision.recommended_tier.value
            )
            
            if success:
                # Update metadata
                await self._update_file_metadata(
                    decision.file_id,
                    {"current_tier": decision.recommended_tier.value}
                )
                
                # Log action
                await self.audit_logger.log_lifecycle_action(decision, success)
                
                self.logger.info(
                    f"Moved file {decision.file_id} from {decision.current_tier.value} "
                    f"to {decision.recommended_tier.value}"
                )
            
            return success
            
        except Exception as e:
            self.logger.error(f"Lifecycle action failed for {decision.file_id}: {str(e)}")
            await self.audit_logger.log_lifecycle_action(decision, False, str(e))
            return False
    
    async def _update_file_metadata(self, file_id: str, updates: Dict[str, Any]) -> None:
        """Update file metadata in database"""
        try:
            async with self.db_pool.get_session() as session:
                await session.execute(
                    "UPDATE files SET metadata = metadata || :updates WHERE file_id = :file_id",
                    {"updates": json.dumps(updates), "file_id": file_id}
                )
                await session.commit()
                
        except Exception as e:
            self.logger.error(f"Failed to update file metadata for {file_id}: {str(e)}")
    
    async def _continuous_optimization(self) -> None:
        """Continuous background optimization of data lifecycle"""
        while True:
            try:
                # Analyze and optimize files in batches
                await self._optimize_files_batch()
                
                # Retrain ML models periodically
                if datetime.utcnow().hour == 2:  # 2 AM daily
                    await self._train_ml_models()
                
                # Sleep until next cycle
                await asyncio.sleep(3600)  # 1 hour
                
            except Exception as e:
                self.logger.error(f"Continuous optimization error: {str(e)}")
                await asyncio.sleep(300)  # 5 minutes before retrying
    
    async def _optimize_files_batch(self) -> None:
        """Optimize a batch of files"""
        try:
            # Get files that need optimization
            files_to_optimize = await self._get_files_for_optimization(limit=100)
            
            for file_id, metadata in files_to_optimize:
                try:
                    decision = await self.analyze_file(file_id, metadata)
                    
                    if decision.action_required:
                        await self.execute_lifecycle_action(decision)
                        
                        # Small delay to avoid overwhelming the system
                        await asyncio.sleep(0.1)
                        
                except Exception as e:
                    self.logger.error(f"Optimization failed for {file_id}: {str(e)}")
            
            self.logger.info(f"Optimized {len(files_to_optimize)} files")
            
        except Exception as e:
            self.logger.error(f"Batch optimization failed: {str(e)}")
    
    async def _get_files_for_optimization(self, limit: int = 100) -> List[Tuple[str, Dict[str, Any]]]:
        """Get files that need lifecycle optimization"""
        try:
            async with self.db_pool.get_session() as session:
                result = await session.execute(
                    "SELECT file_id, metadata FROM files "
                    "WHERE last_optimization_time < NOW() - INTERVAL '7 days' "
                    "OR last_optimization_time IS NULL "
                    "ORDER BY last_access_time DESC LIMIT :limit",
                    {"limit": limit}
                )
                
                return [(row[0], json.loads(row[1])) for row in result.fetchall()]
                
        except Exception as e:
            self.logger.error(f"Failed to get files for optimization: {str(e)}")
            return []
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform lifecycle manager health check"""
        return {
            "initialized": self._initialized,
            "ml_trained": self._ml_trained,
            "policies_loaded": len(self.lifecycle_policies),
            "access_patterns_tracked": len(self.access_patterns),
            "status": "healthy" if self._initialized else "unhealthy"
        }