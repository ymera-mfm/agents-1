// AppContext wrapper
// Re-exports AppContext from store for backward compatibility

export { AppProvider, useApp } from '../store/AppContext';
export * from '../store/AppContext';
