import { errorBoundary } from '../../utils/errorBoundary';

describe('errorBoundary', () => {
  it('is defined', () => {
    expect(errorBoundary).toBeDefined();
  });

  // Add more specific tests for errorBoundary
});
