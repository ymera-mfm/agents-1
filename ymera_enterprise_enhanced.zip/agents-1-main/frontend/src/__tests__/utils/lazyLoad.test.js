import { lazyLoad } from '../../utils/lazyLoad';

describe('lazyLoad', () => {
  it('is defined', () => {
    expect(lazyLoad).toBeDefined();
  });

  // Add more specific tests for lazyLoad
});
