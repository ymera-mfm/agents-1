import { performance } from '../../utils/performance';

describe('performance', () => {
  it('is defined', () => {
    expect(performance).toBeDefined();
  });

  // Add more specific tests for performance
});
