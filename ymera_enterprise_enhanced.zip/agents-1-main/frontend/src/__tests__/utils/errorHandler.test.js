import { errorHandler } from '../../utils/errorHandler';

describe('errorHandler', () => {
  it('is defined', () => {
    expect(errorHandler).toBeDefined();
  });

  // Add more specific tests for errorHandler
});
