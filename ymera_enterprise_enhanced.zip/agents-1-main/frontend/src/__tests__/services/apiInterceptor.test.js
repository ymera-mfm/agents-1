import { apiInterceptor } from '../../utils/apiInterceptor';

describe('apiInterceptor', () => {
  it('is defined', () => {
    expect(apiInterceptor).toBeDefined();
  });

  // Add more specific tests for apiInterceptor
});
