// Config utility wrapper
// Re-exports config from config directory for backward compatibility

import { config } from '../config/config';

export { config };
export default config;
