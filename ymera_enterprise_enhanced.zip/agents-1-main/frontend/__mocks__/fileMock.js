// Jest file mock
// Used to mock file imports in tests (images, fonts, etc.)
module.exports = 'test-file-stub';
