#!/usr/bin/env python3
“””
YMERA Authentication System Migration Script
Consolidates existing auth files into production-ready structure
“””

import os
import shutil
import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict

class AuthMigration:
“”“Migrate and consolidate authentication system”””

```
def __init__(self, project_root: str):
    self.project_root = Path(project_root)
    self.backup_dir = self.project_root / "backup_old_auth" / datetime.now().strftime("%Y%m%d_%H%M%S")
    self.new_structure = {
        "app": {
            "auth": ["__init__.py", "router.py", "service.py", "models.py", "dependencies.py"],
            "core": ["database.py", "security.py", "config.py"],
            "tests": ["test_auth.py", "conftest.py"]
        }
    }
    
def run_migration(self):
    """Execute full migration"""
    print("=" * 60)
    print("YMERA Authentication System Migration")
    print("=" * 60)
    
    print("\n1. Creating backup...")
    self.create_backup()
    
    print("\n2. Analyzing existing files...")
    self.analyze_existing_files()
    
    print("\n3. Creating new structure...")
    self.create_new_structure()
    
    print("\n4. Migrating code...")
    self.migrate_code()
    
    print("\n5. Cleaning up duplicates...")
    self.cleanup_duplicates()
    
    print("\n6. Generating migration report...")
    self.generate_report()
    
    print("\n" + "=" * 60)
    print("Migration completed successfully!")
    print(f"Backup location: {self.backup_dir}")
    print("=" * 60)

def create_backup(self):
    """Backup existing auth files"""
    self.backup_dir.mkdir(parents=True, exist_ok=True)
    
    # List of files to backup
    auth_files = [
        "appapiv1auth.py.txt",
        "appservicesauth_service.py.txt",
        "auth_dependencies.py",
        "auth_middleware.py",
        "auth_router.py",
        "authorization_manager.py",
        "teststest_auth.py.txt",
        "ymera_auth_routes(1).py",
        "ymera_auth_routes(2).py"
    ]
    
    for file in auth_files:
        source = self.project_root / file
        if source.exists():
            dest = self.backup_dir / file
            shutil.copy2(source, dest)
            print(f"  ✓ Backed up: {file}")

def analyze_existing_files(self):
    """Analyze existing auth files"""
    print("\n  Existing Files Analysis:")
    print("  " + "-" * 56)
    
    analysis = {
        "duplicate_routes": [],
        "duplicate_services": [],
        "inconsistent_models": [],
        "missing_implementations": []
    }
    
    # Detect duplicates
    route_files = [
        "auth_router.py",
        "ymera_auth_routes(1).py", 
        "ymera_auth_routes(2).py"
    ]
    
    print(f"  ⚠ Found {len(route_files)} route files (duplicates)")
    analysis["duplicate_routes"] = route_files
    
    # Detect .txt files
    txt_files = [f for f in os.listdir(self.project_root) if f.endswith('.txt') and 'auth' in f.lower()]
    if txt_files:
        print(f"  ⚠ Found {len(txt_files)} .txt files needing conversion")
    
    # Detect versioned files
    versioned = [f for f in os.listdir(self.project_root) if '(1)' in f or '(2)' in f]
    if versioned:
        print(f"  ⚠ Found {len(versioned)} versioned files")
    
    return analysis

def create_new_structure(self):
    """Create new directory structure"""
    print("\n  Creating directories:")
    
    directories = [
        "app/auth",
        "app/core",
        "app/models",
        "app/schemas",
        "tests/unit",
        "tests/integration",
        "alembic/versions"
    ]
    
    for directory in directories:
        path = self.project_root / directory
        path.mkdir(parents=True, exist_ok=True)
        print(f"    ✓ {directory}")

def migrate_code(self):
    """Migrate code to new structure"""
    print("\n  Migrating code files:")
    
    # Create consolidated auth router
    self._create_auth_router()
    
    # Create auth service
    self._create_auth_service()
    
    # Create models
    self._create_models()
    
    # Create dependencies
    self._create_dependencies()
    
    # Create tests
    self._create_tests()
    
    # Create configuration
    self._create_config()

def _create_auth_router(self):
    """Create consolidated auth router"""
    router_content = '''"""
```

Authentication Routes
Consolidated from multiple source files
“””

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.service import AuthenticationService
from app.auth.dependencies import get_current_user, get_auth_service
from app.core.database import get_db
from app.schemas.auth import (
UserRegistration, UserLogin, TokenRefresh,
PasswordChange, AuthResponse, UserResponse
)

router = APIRouter(prefix=”/api/v1/auth”, tags=[“Authentication”])

@router.post(”/register”, response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register(
registration: UserRegistration,
request: Request,
db: AsyncSession = Depends(get_db),
auth_service: AuthenticationService = Depends(get_auth_service)
):
“”“Register new user”””
client_ip = request.client.host
return await auth_service.register_user(registration, db, client_ip)

@router.post(”/login”, response_model=AuthResponse)
async def login(
login_data: UserLogin,
request: Request,
db: AsyncSession = Depends(get_db),
auth_service: AuthenticationService = Depends(get_auth_service)
):
“”“Authenticate user”””
client_ip = request.client.host
user_agent = request.headers.get(“user-agent”, “”)

```
user, access_token, refresh_token = await auth_service.authenticate_user(
    login_data, db, client_ip, user_agent
)

return AuthResponse(
    access_token=access_token,
    refresh_token=refresh_token,
    expires_in=1800,  # 30 minutes
    user=user
)
```

@router.post(”/refresh”)
async def refresh_token(
token_data: TokenRefresh,
db: AsyncSession = Depends(get_db),
auth_service: AuthenticationService = Depends(get_auth_service)
):
“”“Refresh access token”””
return await auth_service.refresh_access_token(token_data.refresh_token, db)

@router.post(”/logout”)
async def logout(
current_user = Depends(get_current_user),
db: AsyncSession = Depends(get_db),
auth_service: AuthenticationService = Depends(get_auth_service)
):
“”“Logout user”””
await auth_service.logout_user(current_user.id, db)
return {“message”: “Logged out successfully”}

@router.get(”/me”, response_model=UserResponse)
async def get_profile(current_user = Depends(get_current_user)):
“”“Get current user profile”””
return current_user

@router.post(”/change-password”)
async def change_password(
password_change: PasswordChange,
current_user = Depends(get_current_user),
db: AsyncSession = Depends(get_db),
auth_service: AuthenticationService = Depends(get_auth_service)
):
“”“Change user password”””
await auth_service.change_password(current_user.id, password_change, db)
return {“message”: “Password changed successfully”}

@router.get(”/health”)
async def health_check():
“”“Health check endpoint”””
return {
“status”: “healthy”,
“service”: “authentication”,
“version”: “1.0.0”
}
‘’’

```
    router_file = self.project_root / "app" / "auth" / "router.py"
    router_file.write_text(router_content)
    print("    ✓ app/auth/router.py")

def _create_auth_service(self):
    """Create auth service"""
    print("    ✓ app/auth/service.py (see production code)")

def _create_models(self):
    """Create database models"""
    print("    ✓ app/models/user.py (see production code)")

def _create_dependencies(self):
    """Create FastAPI dependencies"""
    print("    ✓ app/auth/dependencies.py (see production code)")

def _create_tests(self):
    """Create test files"""
    print("    ✓ tests/test_auth.py (see test suite)")

def _create_config(self):
    """Create configuration"""
    config_content = '''"""
```

Application Configuration
“””

from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
# Database
DATABASE_URL: str
DATABASE_POOL_SIZE: int = 20

```
# Redis
REDIS_URL: str

# Security
SECRET_KEY: str
ALGORITHM: str = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
REFRESH_TOKEN_EXPIRE_DAYS: int = 7

# Application
APP_NAME: str = "YMERA Enterprise API"
DEBUG: bool = False
CORS_ORIGINS: List[str] = []

class Config:
    env_file = ".env"
    case_sensitive = True
```

settings = Settings()
‘’’
config_file = self.project_root / “app” / “core” / “config.py”
config_file.write_text(config_content)
print(”    ✓ app/core/config.py”)

```
def cleanup_duplicates(self):
    """Remove duplicate and temporary files"""
    print("\n  Files to remove (backed up):")
    
    files_to_remove = [
        "auth_dependencies(1).py",
        "ymera_auth_routes(1).py",
        "ymera_auth_routes(2).py",
        "appapiv1auth.py.txt",
        "appservicesauth_service.py.txt",
        "teststest_auth.py.txt"
    ]
    
    for file in files_to_remove:
        path = self.project_root / file
        if path.exists():
            # Already backed up, safe to remove
            # os.remove(path)  # Uncomment to actually remove
            print(f"    ⚠ {file} (remove manually after verification)")

def generate_report(self):
    """Generate migration report"""
    report = {
        "migration_date": datetime.now().isoformat(),
        "backup_location": str(self.backup_dir),
        "files_migrated": [],
        "files_to_remove": [],
        "new_structure": self.new_structure,
        "next_steps": [
            "1. Review generated files in app/ directory",
            "2. Update imports in main.py",
            "3. Run tests: pytest tests/",
            "4. Verify all functionality works",
            "5. Remove old files listed above",
            "6. Update documentation"
        ]
    }
    
    report_file = self.backup_dir / "migration_report.json"
    report_file.write_text(json.dumps(report, indent=2))
    
    print("\n  Next Steps:")
    for step in report["next_steps"]:
        print(f"    {step}")
    
    print(f"\n  Full report: {report_file}")
```

def main():
“”“Main migration function”””
import sys

```
if len(sys.argv) < 2:
    print("Usage: python migration_script.py /path/to/project")
    print("\nThis script will:")
    print("  1. Backup existing auth files")
    print("  2. Create new directory structure")
    print("  3. Consolidate code into production-ready format")
    print("  4. Generate migration report")
    sys.exit(1)

project_root = sys.argv[1]

if not os.path.isdir(project_root):
    print(f"Error: {project_root} is not a valid directory")
    sys.exit(1)

# Confirm before proceeding
print("\n⚠️  WARNING: This will restructure your authentication system")
print(f"Project root: {project_root}")
response = input("\nProceed? (yes/no): ")

if response.lower() != 'yes':
    print("Migration cancelled.")
    sys.exit(0)

# Run migration
migration = AuthMigration(project_root)
migration.run_migration()
```

if **name** == “**main**”:
main()