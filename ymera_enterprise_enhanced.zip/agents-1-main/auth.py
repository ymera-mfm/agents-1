from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from enum import Enum
from datetime import datetime

class UserRole(str, Enum):
    SUPER_ADMIN = "super_admin"
    ADMIN = "admin"
    PROJECT_MANAGER = "project_manager"
    DEVELOPER = "developer"
    ANALYST = "analyst"
    VIEWER = "viewer"
    
class UserBase(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    
class UserCreate(UserBase):
    password: str = Field(..., min_length=12)
    
class UserLogin(BaseModel):
    username: str
    password: str
    
class User(UserBase):
    id: int
    role: str = UserRole.VIEWER.value
    is_active: bool = True
    
    class Config:
        from_attributes = True

# Model used for SQLAlchemy integration
class UserInDB(User):
    hashed_password: str

